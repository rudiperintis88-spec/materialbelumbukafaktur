# Material Belum Dibuka Faktur - paket Vercel

Isi paket:
- index.html     : halaman laporan
- api/sheet.js   : fungsi server yang mengambil Google Sheet (supaya tidak kena batasan CORS browser)
- package.json   : pengaturan minimal (Node 18 ke atas)

Cara pasang:
1. Ekstrak zip ini. Pastikan folder `api` ikut ter-upload bersama index.html
   (struktur harus: index.html dan api/sheet.js di folder yang sama, bukan di dalam folder lain).
2. Deploy ulang proyek Vercel (drag-and-drop folder di vercel.com/new, atau `vercel --prod`).
3. Buka situsnya. Di kanan atas harus tertulis "Live - tersinkron ...".

Syarat Google Sheet: bagikan sebagai "Siapa saja yang memiliki link" (Viewer/Pelihat).

Ganti file Google Sheet tanpa mengubah kode (opsional):
- Di Vercel > Settings > Environment Variables, tambah SHEET_ID = ID file (bagian di antara /d/ dan /edit pada link).
  Catatan: ID yang sama juga tertulis di index.html (cari FILE_ID) untuk jalur cadangan.

Uji cepat fungsi: buka https://NAMA-SITUS.vercel.app/api/sheet -> harus mengunduh file .xlsx.
